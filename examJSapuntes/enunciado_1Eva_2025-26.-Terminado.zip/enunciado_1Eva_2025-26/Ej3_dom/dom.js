
// Ejercicio 3 - DOM y eventos

let peliculas = [
  { titulo: "Matrix" },
  { titulo: "El Padrino" },
  { titulo: "Inception" }
];

  // Al pulsar el botón debes recorrer el array y mostrar cada título como <li>
  
  // Al pasar el ratón por encima, pone el texto en negrita

let boton = document.getElementById("btnMostrar");
let lista = document.getElementById("listaPeliculas");

boton.addEventListener("click", function() {
for (let i = 0; i < peliculas.length; i++) {
    let li = document.createElement("li");

    li.textContent = peliculas[i].titulo;

    lista.appendChild(li);
}
li.addEventListener("mouseover", function() {
    li.style.fontWeight = "bold";
});
li.addEventListener("mouseout", function() {
    li.style.fontWeight = "normal";
});
});