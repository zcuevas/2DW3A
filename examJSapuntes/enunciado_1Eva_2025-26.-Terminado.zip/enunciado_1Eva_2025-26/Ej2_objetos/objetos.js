
// Ejercicio 2 - OBJETOS Y CLASES

// Clase Pelicula
// Constructor con: titulo, director, anio, categoria, valoracion
// Método mostrar() -> "Matrix (1999), dirigida por Wachowski, categoría: Ciencia Ficción"

// Crear al menos 2 objetos y meterlos en un array
// Recorrer y mostrar en consola
class Pelicula {
    constructor(titulo, director, anio, categoria, valoracion) {
        this.titulo = titulo;
        this.director = director;
        this.anio = anio;
        this.categoria = categoria;
        this.valoracion = valoracion;
    }

    mostrar() {
        return this.titulo + " (" + this.anio + "), dirigida por "
            + this.director + ", categoría: " + this.categoria;
    }
}
/*class Pelicula: crea el molde para fabricar películas.
constructor(...): recibe los datos de cada película.
this.titulo = titulo: guarda el título dentro del objeto.
mostrar(): crea el texto que queremos mostrar.*/

let pelicula1 = new Pelicula(
    "Matrix", "Wachowski", 1999, "Ciencia Ficción", 8.7
);

let pelicula2 = new Pelicula(
    "El Padrino", "Francis Ford Coppola", 1972, "Drama", 9.2
);
// La palabra new crea un objeto nuevo usando el molde Pelicula

let listaPeliculas = [pelicula1, pelicula2];

for (let i = 0; i < listaPeliculas.length; i++) {
    console.log(listaPeliculas[i].mostrar());
}
// Así guardamos los dos objetos en una lista y recorremos esa lista para mostrar cada película.