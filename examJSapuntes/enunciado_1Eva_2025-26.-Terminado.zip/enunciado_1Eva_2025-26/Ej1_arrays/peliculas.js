
// Ejercicio 1 - Arrays y sintaxis básica

let peliculas = [
  { titulo: "Dune: Parte Dos", director: "Denis Villeneuve", anio: 2025, categoria: "Ciencia Ficción", valoracion: 8.5 },
  { titulo: "Inside Out 2", director: "Kelsey Mann", anio: 2023, categoria: "Animación", valoracion: 7.8 },
  { titulo: "Mufasa: The Lion King", director: "Barry Jenkins", anio: 2024, categoria: "Aventura", valoracion: 8.0 }
];

// FUNCIONES
// - mayúsculas()
// - peliculasPorCategoria(categoria)
// - buscarPorTitulo(titulo)
// - mediaValoraciones()
function peliculasPorCategoria(categoria) {
    let resultado = [];

    for (let i = 0; i < peliculas.length; i++) {
        if (peliculas[i].categoria === categoria) {
            resultado.push(peliculas[i]);
        }
    }

    return resultado;
}

function buscarPorTitulo(titulo) {
    let resultado = [];

    for (let i = 0; i < peliculas.length; i++) {
        if (peliculas[i].titulo.toLowerCase().includes(titulo.toLowerCase())) {
            resultado.push(peliculas[i]);
        }
    }

    return resultado;
}

function mediaValoraciones() {
    let suma = 0;

    for (let i = 0; i < peliculas.length; i++) {
        suma = suma + peliculas[i].valoracion;
    }

    return suma / peliculas.length;
}

function mayusculas() {
    for (let i = 0; i < peliculas.length; i++) {
        console.log(peliculas[i].titulo.toUpperCase());
    }
}

// Muestra los títulos en mayúsculas
mayusculas();

// Muestra las películas de una categoría
console.log(peliculasPorCategoria("Aventura"));

// Busca películas por título
console.log(buscarPorTitulo("Matrix"));

// Muestra la media de valoraciones
console.log(mediaValoraciones());