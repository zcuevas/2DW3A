
// Ejercicio 5 - Web Storage

  // Si hay usuario en localStorage -> mostrar "Bienvenido de nuevo" y botón cerrar sesión
  // Si no, mostrar formulario
  // Guardar usuario en localStorage si no está vacío 
  // Borrar usuario de localStorage y restaurar formulario



// Localizar elementos HTML
let formulario = document.getElementById("formUsuario");
let mensaje = document.getElementById("mensaje");

// Comprobar si existe un usuario guardado
let usuarioGuardado = localStorage.getItem("usuario");

if (usuarioGuardado !== null) {

    // Mostrar bienvenida
    mensaje.textContent = "Bienvenido de nuevo, " + usuarioGuardado;

    // Ocultar formulario
    formulario.style.display = "none";

    // Crear botón cerrar sesión
    let botonCerrar = document.createElement("button");
    botonCerrar.textContent = "Cerrar sesión";

    // Añadir botón al contenedor
    let contenedor = document.getElementById("contenedor");
    contenedor.appendChild(botonCerrar);

    // Evento para cerrar sesión
    botonCerrar.addEventListener("click", function() {

        // Eliminar usuario de localStorage
        localStorage.removeItem("usuario");

        // Limpiar mensaje
        mensaje.textContent = "";

        // Mostrar formulario
        formulario.style.display = "block";

        // Eliminar botón
        botonCerrar.remove();

    });

}

// Detectar el envío del formulario
formulario.addEventListener("submit", function(event) {

    event.preventDefault();

    // Recoger nombre
    let nombre = document.getElementById("nombreUsuario").value;

    // Comprobar que no esté vacío
    if (nombre.trim() !== "") {
        localStorage.setItem("usuario", nombre);
        location.reload();
    }

});
