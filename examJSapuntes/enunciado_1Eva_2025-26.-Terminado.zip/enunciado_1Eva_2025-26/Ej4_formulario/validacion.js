
// Ejercicio 4 - Validación de formulario

  // Validaciones a implementar:
  // - titulo y director: entre 3 y 50 caracteres
  // - anio: numérico de 4 dígitos entre 1900 y 2099
  // - categoria: no vacía
    let formulario = document.getElementById("formPelicula");
    let mensaje = document.getElementById("mensaje");
    formulario.addEventListener("submit", function(event){ 
       event.preventDefault();
      //recoger los datos del formulario
      let titulo = document.getElementById("titulo").value;
      let director = document.getElementById("director").value;
      let anio = document.getElementById("anio").value;
      let categoria = document.getElementById("categoria").value;

      let patron = /^[a-zA-Z]{3,50}$/;
      let tituloValido = patron.test(titulo);
      let directorValido = patron.test(director);

      // Variable para saber si hay errores
      let valido = true;
      let errores = [];

      // Validar título y director
      if(!tituloValido || !directorValido){
        valido = false;
        errores.push("El título o el director no son válidos");
        
      }
      
      let numeroAnio = Number(anio);
      // Validar año
      if(anio.length !== 4 || numeroAnio < 1900 || numeroAnio > 2099 || Number.isNaN(numeroAnio)){
        valido = false;
        errores.push("El año no es válido");
      }
      // Validar categoría
      if(categoria === "") {
      // Mostrar mensaje de error
      valido = false;
      errores.push("Debes seleccionar una categoría");
    }
    
    // Comprobar el resultado final
    if(valido){
      mensaje.textContent = "Película validada correctamente";
    }else{
      mensaje.textContent = "Errores: " + errores.join(", ");
    }
  });
    
  // Al enviar el formulario, mostrar mensajes de error o éxito en el div#mensaje