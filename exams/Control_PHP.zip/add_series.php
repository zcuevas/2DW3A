<?php

require "includes/datuak.php";
require "includes/funtzioak.php";
include "header.php";

?>

<h1>Serie berria gehitu</h1>

<form action="add_series.php" method="post">

    <label for="izenburua">Izenburua:</label>
    <input type="text" id="izenburua" name="izenburua">

     <label for="generoa">Generoa:</label>
        <select name="generoa" id="generoa">
            <option value="">Guztiak</option>
            <option value="Zientzia fikzioa">Zientzia fikzioa</option>
            <option value="Drama">Drama</option>
            <option value="Fantasia">Fantasia</option>
            <option value="Thriller">Thriller</option>
        </select>

    <label for="denboraldiak">Denboraldi kopurua:</label>
    <input type="number" id="denboraldiak" name="denboraldiak" min="1">

    <label for="balorazioa">Balorazioa:</label>
    <input type="number" id="balorazioa" name="balorazioa" min="0" max="10" step="0.1">

    <label for="amaituta">Egoera:</label>

    <select id="amaituta" name="amaituta">
        <option value="0">Martxan</option>
        <option value="1">Amaituta</option>
    </select>

    <button type="submit"  name="gehitu">Seriea gehitu</button>

</form>

<?php

if (isset($_POST["gehitu"])) {

    $izenburua = $_POST["izenburua"];
    $generoa = $_POST["generoa"];
    $denboraldiak = $_POST["denboraldiak"];
    $balorazioa = $_POST["balorazioa"];

    if ($_POST["amaituta"] == 1) {
        $amaituta = true;
    } else {
        $amaituta = false;
    }

    $series = serieaGehitu($series,$izenburua,$generoa,$denboraldiak,$balorazioa,$amaituta);

    echo "<h2>Serie berria</h2>";

    $serieBerria = [
        $series[count($series) - 1]
    ];

    serieakErakutsi($serieBerria);
}

include "footer.php";

?>