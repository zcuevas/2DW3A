<?php

require "includes/datuak.php";
require "includes/funtzioak.php";
include "header.php";

$serieKopurua = count($series);
$amaituGabeak = martxanKalkulatu($series);
$batezbestekoa = batezbestekoaKalkulatu($series);
$serieAltuena = balorazioAltuena($series);

?>

<h1>Estatistikak</h1>

<section class="estatistikak">

    <article class="estatistika">
        <h2>Serie kopurua</h2>
        <p><?php echo $serieKopurua; ?></p>
    </article>

    <article class="estatistika">
        <h2>Martxan dauden serieak</h2>
        <p><?php echo $amaituGabeak; ?></p>
    </article>

    <article class="estatistika">
        <h2>Batez besteko balorazioa</h2>
        <p><?php echo round($batezbestekoa, 2); ?></p>
    </article>

    <article class="estatistika">
        <h2>Baloraziorik altuena</h2>

        <p>
            <?php echo $serieAltuena["izenburua"]; ?>
            -
            <?php echo $serieAltuena["balorazioa"]; ?>
        </p>
    </article>

</section>

<?php

include "footer.php";

?>