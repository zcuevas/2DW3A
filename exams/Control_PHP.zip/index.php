<?php

require "includes/datuak.php";
require "includes/funtzioak.php";

include "header.php";

?>

<h1>Serieak</h1>

<?php

serieakErakutsi($series);

include "footer.php";

?>