<?php

function serieakErakutsi($series) {

    echo '<section class="serieak">';

    foreach ($series as $serie) {

        echo '<article class="seriea">';

        if (isset($serie["irudia"])) {
            echo '<img src="' . $serie["irudia"] . '">';
        } else {
            echo '<img src="img/default.jpg">';
        }

        echo '<div>';
        echo '<h2>' . $serie["izenburua"] . '</h2>';
        echo '<p>' . $serie["generoa"] . '</p>';
        echo '<p>' . $serie["denboraldiak"] . ' denboraldi</p>';
        echo '<p>Balorazioa: ' . $serie["balorazioa"] . '</p>';

        if ($serie["amaituta"]) {
            echo '<p>Amaituta</p>';
        } else {
            echo '<p>Martxan</p>';
        }

        echo '</div>';
        echo '</article>';
    }

    echo '</section>';
}


function serieakBilatu($series, $testua) {

    $emaitzak = [];

    foreach ($series as $serie) {
        if (stripos($serie["izenburua"], $testua) !== false) {
            $emaitzak[] = $serie;
        }
    }

    return $emaitzak;
}


function serieaGehitu($series, $izenburua, $generoa, $denboraldiak, $balorazioa, $amaituta) {

    $serieBerria = [
        "izenburua" => $izenburua,
        "generoa" => $generoa,
        "denboraldiak" => $denboraldiak,
        "balorazioa" => $balorazioa,
        "amaituta" => $amaituta,
        "irudia" => "img/default.jpg"
    ];

    $series[] = $serieBerria;

    return $series;
}


function martxanKalkulatu($series) {

    $kopurua = 0;

    foreach ($series as $serie) {

        if (!$serie["amaituta"]) {
            $kopurua++;
        }
    }

    return $kopurua;
}


function batezbestekoaKalkulatu($series) {

    $guztira = 0;

    foreach ($series as $serie) {
        $guztira += $serie["balorazioa"];
    }

    return $guztira / count($series);
}


function balorazioAltuena($series) {

    $serieAltuena = $series[0];

    foreach ($series as $serie) {

        if ($serie["balorazioa"] > $serieAltuena["balorazioa"]) {
            $serieAltuena = $serie;
        }
    }

    return $serieAltuena;
}