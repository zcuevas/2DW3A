<?php

require "includes/datuak.php";
require "includes/funtzioak.php";
include "header.php";

?>

<h1>Serieak bilatu</h1>

<form action="search.php" method="post">

    <label for="bilaketa">Seriearen izenburua:</label>

    <input
        type="text"
        id="bilaketa"
        name="bilaketa"
        required
    >

    <button type="submit" name="bilatu">Bilatu</button>

</form>

<?php

if (isset($_POST["bilatu"])) {

    $testua = $_POST["bilaketa"];

    $emaitzak = serieakBilatu($series, $testua);

    if (count($emaitzak) > 0) {
        echo "<h2>Bilaketaren emaitzak</h2>";
        serieakErakutsi($emaitzak);

    } else {
        echo "<p>Ez da serierik aurkitu.</p>";
    }
}

include "footer.php";

?>